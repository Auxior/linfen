<!--
 * @Author: your name
 * @Date: 2021-11-27 19:52:04
 * @LastEditTime: 2021-11-27 22:18:10
 * @LastEditors: your name
 * @Description: 打开koroFileHeader查看配置 进行设置: https://github.com/OBKoro1/koro1FileHeader/wiki/%E9%85%8D%E7%BD%AE
 * @FilePath: \vue3ts\vue3\src\App.vue
-->
<template>
  <router-view />
</template>
