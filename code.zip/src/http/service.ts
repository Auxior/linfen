const Service = {
  // 请求地址 开发环境下使用代理
  mdoel1: 'http://127.0.0.1:3300',
  WeatherId: 'https://geoapi.qweather.com',
  WeatherData: 'https://devapi.qweather.com',
};
export { Service };
