import {
  AXIS_LABEL,
  LEGEND,
  LINE_TOOLTIP,
  XAXIS_NAME,
  YAXIS_NAME,
} from "@/utils/chartConfig";
import * as echarts from "echarts";
