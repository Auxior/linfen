<template>
  <div class="orderTime">
      orderTime
  </div>
</template>

<script lang="ts">
import {defineComponent} from 'vue'
export default defineComponent({
    setup(){

    }

})

</script>
<style lang="scss" scoped>
.orderTime {
    width: 100%;
    height: 210px;
    // border: 1px solid red;
    padding: 5px;
    background-color: #192333;
    
}
</style>