<!--
 * @Author: your name
 * @Date: 2022-02-22 21:21:48
 * @LastEditTime: 2022-02-24 21:48:14
 * @LastEditors: Please set LastEditors
 * @Description: 打开koroFileHeader查看配置 进行设置: https://github.com/OBKoro1/koro1FileHeader/wiki/%E9%85%8D%E7%BD%AE
 * @FilePath: \DTSWeekly_zhyq\src\Views\home\Eighth\index.vue
-->
<!-- Eighth 第八个页面-（名称） -->
<template>
  <div class="Eighth">
    <Left_box>
      <div class="a">
        <p>Eighth</p>
      </div>
    </Left_box>

    <Right_box>Eighth</Right_box>
  </div>
</template>

<script lang="ts" setup>
import Left_box from "@/components/left_box.vue";
import Right_box from "@/components/right_box.vue";
</script>
<style lang="scss" scoped></style>
