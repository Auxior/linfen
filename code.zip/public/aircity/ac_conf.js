/**
 * Configuration file modification instructions
 * Player: Address for Cloud connection video streaming and API calls
 * Path: The absolute path where the SDK folder is located (for setting the path of test data in the sample code)
 */
var HostConfig = {
  "Player": "192.168.3.67:8080",
  "Path": "D:/softwares/DTS Cloud/6.0/SDK",
  "UseHttps": false
}